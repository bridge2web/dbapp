<template>
    <img src="../assets/images/logo.svg" class="logo" alt="Логотип">
</template>

<script>
    export default {
        name: 'logo'
    }
</script>

<style>
    .logo {
        width: 136px;
        height: auto;
    }
</style>
